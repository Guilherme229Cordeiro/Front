﻿namespace ClientRCL.Interfaces
{
    public interface ISecureStorageService
    {
        Task SetAsync(string key, object value);
        Task<T?> GetAsync<T>(string key);
        Task DeleteAsync(string key);
    }
}