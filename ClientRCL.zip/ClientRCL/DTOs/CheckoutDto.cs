﻿namespace ClientRCL.DTOs
{
    public class CheckoutDto
    {
        public List<DetalheCheckoutDto> Itens { get; set; } = new();
    }

    public class DetalheCheckoutDto
    {
        public int ArtigoId { get; set; }
        public int Quantidade { get; set; }
    }
}