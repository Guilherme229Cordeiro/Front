﻿using System.ComponentModel.DataAnnotations;

namespace ClientRCL.DTOs
{
    public class LoginDto
    {
        [Required(ErrorMessage = "O Email é obrigatório.")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "A Password é obrigatória.")]
        public string Password { get; set; } = string.Empty;
    }
}