﻿using System.ComponentModel.DataAnnotations;

namespace ClientRCL.DTOs
{
    public class RegisterDto
    {
        [Required(ErrorMessage = "O Email é obrigatório.")]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "A Password é obrigatória.")]
        [MinLength(6, ErrorMessage = "A password deve ter pelo menos 6 caracteres.")]
        public string Password { get; set; } = string.Empty;

        [Required(ErrorMessage = "O Nome é obrigatório.")]
        public string Nome { get; set; } = string.Empty;

        [Required(ErrorMessage = "O Apelido é obrigatório.")]
        public string Apelido { get; set; } = string.Empty;

        [Required(ErrorMessage = "O NIF é obrigatório.")]
        public int NIF { get; set; }

        [Required]
        public string TipoUtilizador { get; set; } = "Cliente"; // Valor por defeito
    }
}