﻿using Shared; // Para conhecer o modelo 'Artigo'
using System.Net.Http.Json;

namespace ClientRCL.Services
{
    public class ArtigoService
    {
        private readonly HttpClient _http;

        public ArtigoService(HttpClient http)
        {
            _http = http;
        }

        // Obtém a lista de artigos ativos da API
        public async Task<List<Artigo>> GetArtigosAsync()
        {
            try
            {
                // Chama o endpoint público que criámos na API (GET /api/artigos)
                var resultado = await _http.GetFromJsonAsync<List<Artigo>>("api/artigos");
                return resultado ?? new List<Artigo>();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao buscar artigos: {ex.Message}");
                return new List<Artigo>(); // Retorna lista vazia para não dar erro na página
            }
        }
        // Obtém um artigo pelo seu Id
        public async Task<Artigo?> GetArtigoByIdAsync(int id)
        {
            try { return await _http.GetFromJsonAsync<Artigo>($"api/artigos/{id}"); }
            catch { return null; }
        }

        // Obtém a lista de categorias da API
        public async Task<List<Categoria>> GetCategoriasAsync()
        {
            try
            {
                var resultado = await _http.GetFromJsonAsync<List<Categoria>>("api/categorias");
                return resultado ?? new List<Categoria>();
            }
            catch
            {
                return new List<Categoria>();
            }
        }
    }
}