﻿using ClientRCL.DTOs;
using ClientRCL.Interfaces; // Namespace da Interface
using Microsoft.AspNetCore.Components.Authorization;
using System.Net.Http.Json;
using System.Text.Json;

namespace ClientRCL.Services
{
    public class AuthService
    {
        private readonly HttpClient _http;
        private readonly ISecureStorageService _storage; // Usa a Interface
        private readonly AuthenticationStateProvider _authStateProvider;

        public AuthService(HttpClient http, ISecureStorageService storage, AuthenticationStateProvider authStateProvider)
        {
            _http = http;
            _storage = storage;
            _authStateProvider = authStateProvider;
        }

        public async Task<string> Login(LoginDto loginModel)
        {
            try
            {
                var response = await _http.PostAsJsonAsync("api/auth/login", loginModel);

                if (response.IsSuccessStatusCode)
                {
                    var result = await response.Content.ReadFromJsonAsync<JsonElement>();
                    string token = result.GetProperty("token").GetString() ?? "";

                    // Guarda usando a interface genérica
                    await _storage.SetAsync("authToken", token);

                    await ((CustomAuthStateProvider)_authStateProvider).MarkUserAsAuthenticated(token);
                    return "Sucesso";
                }
                return await response.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            {
                return $"Erro: {ex.Message}";
            }
        }

        public async Task<string> Register(RegisterDto registerModel)
        {
            try
            {
                var response = await _http.PostAsJsonAsync("api/auth/register", registerModel);
                if (response.IsSuccessStatusCode) return "Sucesso";
                return await response.Content.ReadAsStringAsync();
            }
            catch (Exception ex)
            {
                return $"Erro: {ex.Message}";
            }
        }

        public async Task Logout()
        {
            await _storage.DeleteAsync("authToken");
            ((CustomAuthStateProvider)_authStateProvider).MarkUserAsLoggedOut();
        }
    }
}