﻿using ClientRCL.DTOs;
using System.Net.Http.Json;
using Blazored.LocalStorage;
using Microsoft.AspNetCore.Components.Authorization;

namespace ClientRCL.Services
{
    public class AuthService
    {
        private readonly HttpClient _httpClient;
        private readonly ILocalStorageService _localStorage;
        private readonly AuthenticationStateProvider _authStateProvider;

        public AuthService(HttpClient httpClient,
                           ILocalStorageService localStorage,
                           AuthenticationStateProvider authStateProvider)
        {
            _httpClient = httpClient;
            _localStorage = localStorage;
            _authStateProvider = authStateProvider;
        }

        public async Task<bool> Login(LoginDto loginModel)
        {
            try
            {
                // Tenta chamar a API
                var response = await _httpClient.PostAsJsonAsync("api/auth/login", loginModel);

                if (response.IsSuccessStatusCode)
                {
                    var result = await response.Content.ReadFromJsonAsync<LoginResponse>();
                    await _localStorage.SetItemAsync("authToken", result.Token);
                    ((CustomAuthStateProvider)_authStateProvider).NotifyUserAuthentication(result.Token);
                    return true;
                }
                else
                {
                    // Opcional: Ler o erro do servidor para debugging
                    var erro = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"Erro API: {response.StatusCode} - {erro}");
                    return false;
                }
            }
            catch (Exception ex)
            {
                // ISTO É O IMPORTANTE: Vai mostrar no output do Visual Studio se falhar a conexão
                Console.WriteLine($"EXCEPÇÃO AO LOGIN: {ex.Message}");
                return false;
            }
        }

        public async Task<string> Register(RegisterDto registerModel)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync("api/auth/register", registerModel);

                if (response.IsSuccessStatusCode)
                {
                    return "Sucesso";
                }

                // Lê o erro que veio da API (ex: Password fraca, Role inexistente)
                var erro = await response.Content.ReadAsStringAsync();
                return erro;
            }
            catch (Exception ex)
            {
                // Isto vai apanhar erros de conexão (CORS) ou servidor desligado
                return $"Erro de conexão: {ex.Message}";
            }
        }

        public async Task Logout()
        {
            // 1. Remove o Token
            await _localStorage.RemoveItemAsync("authToken");

            // 2. Notifica o Provider que o utilizador saiu!
            ((CustomAuthStateProvider)_authStateProvider).NotifyUserLogout();
        }
    }

    public class LoginResponse
    {
        public string Token { get; set; }
    }
}