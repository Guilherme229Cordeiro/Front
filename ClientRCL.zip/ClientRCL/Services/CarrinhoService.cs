﻿using Blazored.LocalStorage;
using ClientRCL.Models;
using Shared;

namespace ClientRCL.Services
{
    public class CarrinhoService
    {
        private readonly ILocalStorageService _localStorage;
        private const string Key = "carrinho";

        // Evento para avisar o Menu que o carrinho mudou
        public event Action OnChange;

        public CarrinhoService(ILocalStorageService localStorage)
        {
            _localStorage = localStorage;
        }

        public async Task AdicionarAoCarrinho(Artigo artigo, int quantidade = 1)
        {
            var carrinho = await GetCarrinho();
            var item = carrinho.FirstOrDefault(i => i.ArtigoId == artigo.Id);

            if (item == null)
            {
                carrinho.Add(new ItemCarrinho
                {
                    ArtigoId = artigo.Id,
                    Titulo = artigo.Titulo,
                    Preco = artigo.Preco,
                    Imagem = null,
                    Quantidade = quantidade // Usa a quantidade passada
                });
            }
            else
            {
                item.Quantidade += quantidade; // Soma a quantidade passada
            }

            await _localStorage.SetItemAsync(Key, carrinho);
            OnChange?.Invoke();
        }

        public async Task<List<ItemCarrinho>> GetCarrinho()
        {
            // Se der erro a ler (ex: json corrompido), devolve lista vazia
            try
            {
                var carrinho = await _localStorage.GetItemAsync<List<ItemCarrinho>>(Key);
                return carrinho ?? new List<ItemCarrinho>();
            }
            catch
            {
                return new List<ItemCarrinho>();
            }
        }

        public async Task RemoverItem(int artigoId)
        {
            var carrinho = await GetCarrinho();
            var item = carrinho.FirstOrDefault(i => i.ArtigoId == artigoId);

            if (item != null)
            {
                carrinho.Remove(item);
                await _localStorage.SetItemAsync(Key, carrinho);
                OnChange?.Invoke();
            }
        }

        public async Task LimparCarrinho()
        {
            await _localStorage.RemoveItemAsync(Key);
            OnChange?.Invoke();
        }
    }
}