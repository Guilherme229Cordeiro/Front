﻿using ClientRCL.Interfaces;
using ClientRCL.Models;
using Shared;
using Microsoft.AspNetCore.Components.Authorization;
using System.Security.Claims; // Necessário para os Claims

namespace ClientRCL.Services
{
    public class CarrinhoService
    {
        private readonly ISecureStorageService _storage;
        private readonly AuthenticationStateProvider _authStateProvider;
        private const string KeyVisitante = "carrinho_visitante";

        public event Action? OnChange;

        public CarrinhoService(ISecureStorageService storage, AuthenticationStateProvider authStateProvider)
        {
            _storage = storage;
            _authStateProvider = authStateProvider;
        }

        // --- CORREÇÃO AQUI: Lógica Robusta de Identificação ---
        private async Task<string> ObterChaveStorage()
        {
            var authState = await _authStateProvider.GetAuthenticationStateAsync();
            var user = authState.User;

            if (user.Identity != null && user.Identity.IsAuthenticated)
            {
                // 1. Tenta o Name padrão
                string? identificador = user.Identity.Name;

                // 2. Se falhar, tenta o Email (padrão JWT "email")
                if (string.IsNullOrEmpty(identificador))
                    identificador = user.FindFirst("email")?.Value;

                // 3. Se falhar, tenta "unique_name" ou "sub"
                if (string.IsNullOrEmpty(identificador))
                    identificador = user.FindFirst(c => c.Type == "unique_name" || c.Type == "sub")?.Value;

                // Se encontrou algo, cria uma chave única para este utilizador
                if (!string.IsNullOrEmpty(identificador))
                {
                    return $"carrinho_user_{identificador}";
                }
            }

            // Se não estiver logado ou não encontrar ID, é visitante
            return KeyVisitante;
        }

        public async Task AdicionarAoCarrinho(Artigo artigo, int quantidade = 1)
        {
            try
            {
                string key = await ObterChaveStorage();
                var result = await _storage.GetAsync<List<ItemCarrinho>>(key);
                var carrinho = result ?? new List<ItemCarrinho>();

                var item = carrinho.FirstOrDefault(i => i.ArtigoId == artigo.Id);

                if (item == null)
                {
                    carrinho.Add(new ItemCarrinho
                    {
                        ArtigoId = artigo.Id,
                        Titulo = artigo.Titulo,
                        Preco = artigo.Preco,
                        Imagem = null,
                        Quantidade = quantidade
                    });
                }
                else
                {
                    item.Quantidade += quantidade;
                }

                await _storage.SetAsync(key, carrinho);
                OnChange?.Invoke();
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }
        }

        public async Task<List<ItemCarrinho>> GetCarrinho()
        {
            try
            {
                string key = await ObterChaveStorage();
                var result = await _storage.GetAsync<List<ItemCarrinho>>(key);
                return result ?? new List<ItemCarrinho>();
            }
            catch { return new List<ItemCarrinho>(); }
        }

        public async Task RemoverItem(int artigoId)
        {
            try
            {
                string key = await ObterChaveStorage();
                var result = await _storage.GetAsync<List<ItemCarrinho>>(key);
                if (result != null)
                {
                    var item = result.FirstOrDefault(i => i.ArtigoId == artigoId);
                    if (item != null)
                    {
                        result.Remove(item);
                        await _storage.SetAsync(key, result);
                        OnChange?.Invoke();
                    }
                }
            }
            catch { }
        }

        public async Task LimparCarrinho()
        {
            string key = await ObterChaveStorage();
            await _storage.DeleteAsync(key);
            OnChange?.Invoke();
        }

        // --- CORREÇÃO AQUI: Recebe o email explicitamente ---
        public async Task MesclarCarrinhoLogin(string emailUtilizador)
        {
            try
            {
                // 1. Busca itens do visitante (antes do login)
                var itensVisitante = await _storage.GetAsync<List<ItemCarrinho>>(KeyVisitante);

                if (itensVisitante != null && itensVisitante.Any())
                {
                    // 2. Define a chave do utilizador explicitamente com o email que acabou de entrar
                    string keyUser = $"carrinho_user_{emailUtilizador}";

                    // 3. Busca o carrinho existente desse utilizador
                    var itensUserResult = await _storage.GetAsync<List<ItemCarrinho>>(keyUser);
                    var itensUser = itensUserResult ?? new List<ItemCarrinho>();

                    // 4. Junta os itens
                    foreach (var itemV in itensVisitante)
                    {
                        var existente = itensUser.FirstOrDefault(u => u.ArtigoId == itemV.ArtigoId);
                        if (existente != null)
                        {
                            existente.Quantidade += itemV.Quantidade;
                        }
                        else
                        {
                            itensUser.Add(itemV);
                        }
                    }

                    // 5. Salva na conta e apaga do visitante
                    await _storage.SetAsync(keyUser, itensUser);
                    await _storage.DeleteAsync(KeyVisitante);

                    OnChange?.Invoke();
                }
            }
            catch { /* Ignora erros */ }
        }
    }
}