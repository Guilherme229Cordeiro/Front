﻿using ClientRCL.DTOs;
using ClientRCL.Models;
using Shared;
using System.Net.Http;
using System.Net.Http.Json;

namespace ClientRCL.Services
{
    public class EncomendaService
    {
        private readonly HttpClient _http;

        public EncomendaService(HttpClient http)
        {
            _http = http;
        }

        public async Task<string> FinalizarEncomenda(List<ItemCarrinho> itensCarrinho)
        {
            try
            {
                // 1. Converter o Carrinho Local para o formato que a API exige
                var checkoutDto = new CheckoutDto
                {
                    Itens = itensCarrinho.Select(i => new DetalheCheckoutDto
                    {
                        ArtigoId = i.ArtigoId,
                        Quantidade = i.Quantidade
                    }).ToList()
                };

                // 2. Enviar para a API
                var response = await _http.PostAsJsonAsync("api/encomendas", checkoutDto);

                if (response.IsSuccessStatusCode)
                {
                    return "Sucesso";
                }

                // Se der erro (ex: stock insuficiente), lê a mensagem da API
                var erro = await response.Content.ReadAsStringAsync();
                return erro;
            }
            catch (Exception ex)
            {
                return $"Erro de comunicação: {ex.Message}";
            }
        }

        // 3. O método para buscar o histórico
        public async Task<List<Encomenda>> GetMinhasEncomendas()
        {
            // Nota: "api/encomendas/historico" tem de bater certo com o controller
            var result = await _http.GetFromJsonAsync<List<Encomenda>>("api/encomendas/historico");
            return result ?? new List<Encomenda>();
        }
    }
}