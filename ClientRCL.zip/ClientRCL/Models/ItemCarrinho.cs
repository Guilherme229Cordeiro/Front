﻿namespace ClientRCL.Models
{
    public class ItemCarrinho
    {
        public int ArtigoId { get; set; }
        public string Titulo { get; set; }
        public decimal Preco { get; set; }
        public byte[] Imagem { get; set; }
        public int Quantidade { get; set; } = 1;
    }
}