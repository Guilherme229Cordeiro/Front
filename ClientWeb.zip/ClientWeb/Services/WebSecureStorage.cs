﻿using ClientRCL.Interfaces;
using Microsoft.AspNetCore.Components.Server.ProtectedBrowserStorage;

namespace ClientWeb.Services
{
    public class WebSecureStorage : ISecureStorageService
    {
        private readonly ProtectedLocalStorage _protectedStorage;

        public WebSecureStorage(ProtectedLocalStorage protectedStorage)
        {
            _protectedStorage = protectedStorage;
        }

        public async Task SetAsync(string key, object value)
        {
            try { await _protectedStorage.SetAsync(key, value); }
            catch { /* Ignora erros de prerender */ }
        }

        public async Task<T?> GetAsync<T>(string key)
        {
            try
            {
                var result = await _protectedStorage.GetAsync<T>(key);
                return result.Success ? result.Value : default;
            }
            catch
            {
                // Retorna null durante o prerendering ou erro
                return default;
            }
        }

        public async Task DeleteAsync(string key)
        {
            try { await _protectedStorage.DeleteAsync(key); }
            catch { }
        }
    }
}