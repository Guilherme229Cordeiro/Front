using ClientRCL.Interfaces;
using ClientRCL.Services;
using ClientWeb.Components;
using ClientWeb.Services; // Necess�rio para WebSecureStorage
using Microsoft.AspNetCore.Components.Authorization;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// --- ZONA DE SERVI�OS ---

// 1. HttpClient (Verifique se a porta 7053 � a correta da sua API)
builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri("https://localhost:7053") });

// 2. Servi�o de Armazenamento Seguro (Substitui o Blazored)
// Mapeia a Interface (usada na RCL) para a Implementa��o Web (usada aqui)
builder.Services.AddScoped<ISecureStorageService, WebSecureStorage>();

// 3. Autentica��o Personalizada
builder.Services.AddScoped<AuthenticationStateProvider, CustomAuthStateProvider>();
builder.Services.AddAuthenticationCore();

// 4. Servi�os de Neg�cio (RCL)
builder.Services.AddScoped<AuthService>();
builder.Services.AddScoped<ArtigoService>();
builder.Services.AddScoped<CarrinhoService>();
builder.Services.AddScoped<EncomendaService>();

// --- FIM ZONA DE SERVI�OS ---

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode()
    .AddAdditionalAssemblies(typeof(ClientRCL.Components.Pages.Home).Assembly);

app.Run();