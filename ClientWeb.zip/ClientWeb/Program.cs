using Blazored.LocalStorage;
using ClientRCL.Components.Layout;
using ClientRCL.Services;
using ClientWeb.Components;
using Microsoft.AspNetCore.Components.Authorization;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();


// 1. O HttpClient a apontar para a API (verifique a porta!)
builder.Services.AddScoped(sp => new HttpClient
{
    BaseAddress = new Uri("https://localhost:7053") // <-- Confirme a porta da sua API
});

// 2. LocalStorage
builder.Services.AddBlazoredLocalStorage();

// 3. O nosso AuthService
builder.Services.AddScoped<AuthService>();

// 4. O nosso ArtigoService
builder.Services.AddScoped<ClientRCL.Services.ArtigoService>();

// 5. O nosso CarrinhoService
builder.Services.AddScoped<ClientRCL.Services.CarrinhoService>();

// 4. Configura��o da Autentica��o com o nosso Provider Personalizado
builder.Services.AddAuthorizationCore();
builder.Services.AddScoped<AuthenticationStateProvider, CustomAuthStateProvider>();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode()
    .AddAdditionalAssemblies(typeof(MainLayout).Assembly);

app.Run();
