using ClientRCL.Interfaces;
using ClientRCL.Services;
using ClientWeb.Components;
using ClientWeb.Services;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Authentication.Cookies; // <--- NECESS�RIO

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// --- ZONA DE SERVI�OS ---

// 1. HttpClient
builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri("https://localhost:7053") });

// 2. Servi�o de Armazenamento Seguro
builder.Services.AddScoped<ISecureStorageService, WebSecureStorage>();

// 3. Autentica��o (AQUI ESTAVA O ERRO)
// Adicionamos Cookies para que o servidor saiba o que fazer quando encontra o [Authorize]
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/login"; // Se n�o estiver logado, manda para aqui
    });

builder.Services.AddScoped<AuthenticationStateProvider, CustomAuthStateProvider>();
builder.Services.AddAuthenticationCore(); // Mant�m este para o Blazor

// 4. Servi�os de Neg�cio (RCL)
builder.Services.AddScoped<AuthService>();
builder.Services.AddScoped<ArtigoService>();
builder.Services.AddScoped<CarrinhoService>();
builder.Services.AddScoped<EncomendaService>();

// --- FIM ZONA DE SERVI�OS ---

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseAntiforgery();

// --- ADICIONA ESTES MIDDLEWARES ---
app.UseAuthentication();
app.UseAuthorization();
// ---------------------------------

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode()
    .AddAdditionalAssemblies(typeof(ClientRCL.Components.Pages.Home).Assembly);

app.Run();