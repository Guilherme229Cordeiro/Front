﻿using System.ComponentModel.DataAnnotations;

namespace Shared
{
    public class ModoDisponibilizacao
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "O nome é obrigatório (ex: Venda, Aluguer, Listagem)")]
        public string Nome { get; set; } = string.Empty;
    }
}