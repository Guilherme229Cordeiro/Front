﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Shared
{
    // Enum para o estado (Requisito do Tema A)
    public enum EstadoArtigo
    {
        Pendente,
        Ativo,
        Inativo
    }

    public class Artigo
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "O título é obrigatório")]
        public string Titulo { get; set; } = string.Empty;

        [Required]
        public string Descricao { get; set; } = string.Empty;

        // --- Lógica de Preços (Tema A) ---
        [Column(TypeName = "decimal(10,2)")]
        public decimal PrecoBase { get; set; } // O Fornecedor define este

        [Column(TypeName = "decimal(10,2)")]
        public decimal MargemLucro { get; set; } // O Admin define esta (ex: 20 para 20%)

        // Este é o antigo "Preco" que será calculado: PrecoBase + Margem
        [Column(TypeName = "decimal(10,2)")]
        public decimal Preco { get; set; }


        [Required(ErrorMessage = "A quantidade em stock é obrigatória")]
        [Range(0, int.MaxValue, ErrorMessage = "O stock não pode ser negativo")]
        public int Stock { get; set; } = 0;


        // --- Imagens (Igual ao código do Professor) ---
        public string? ImagemUrl { get; set; } // Guarda o nome do ficheiro

        public byte[]? Imagem { get; set; } // Guarda a imagem em si na BD

        [NotMapped]
        public Microsoft.AspNetCore.Http.IFormFile? ImageFile { get; set; }

        // --- Categorias e Estado ---
        public string CategoriaMedia { get; set; } = "DVD"; // DVD, Vinil, CD

        public bool isUsado { get; set; } = false;

        public EstadoArtigo Estado { get; set; } = EstadoArtigo.Pendente;

        // Relacionamentos
        public int CategoriaId { get; set; }
        public Categoria? Categoria { get; set; }

        public string? FornecedorId { get; set; } // ID do utilizador que criou

        public string? TipoMedia { get; set; } // Ex: Filme, Musica, Jogo


        // Chave Estrangeira
        public int ModoDisponibilizacaoId { get; set; }

        // Propriedade de Navegação
        public ModoDisponibilizacao? ModoDisponibilizacao { get; set; }
    }
}