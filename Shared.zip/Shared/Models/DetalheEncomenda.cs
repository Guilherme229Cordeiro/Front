﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Shared
{
    public class DetalheEncomenda
    {
        public int Id { get; set; }

        // A que encomenda pertence?
        public int EncomendaId { get; set; }
        public Encomenda? Encomenda { get; set; }

        // Que artigo é?
        public int ArtigoId { get; set; }
        public Artigo? Artigo { get; set; }

        public int Quantidade { get; set; }

        // Preço no momento da compra (importante se o preço mudar depois)
        [Column(TypeName = "decimal(10,2)")]
        public decimal PrecoUnitario { get; set; }
    }
}