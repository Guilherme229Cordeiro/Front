﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Shared
{
    public enum EstadoEncomenda
    {
        Pendente,   // Cliente finalizou, mas ainda não pagou
        Paga,       // Pagamento confirmado (Pronto a expedir)
        Enviada,    // Saiu da loja (Stock descontado)
        Cancelada   // Anulada
    }

    public class Encomenda
    {
        public int Id { get; set; }

        public DateTime Data { get; set; } = DateTime.Now;

        [Column(TypeName = "decimal(10,2)")]
        public decimal ValorTotal { get; set; }

        public EstadoEncomenda Estado { get; set; } = EstadoEncomenda.Pendente;

        // Quem comprou? (Ligação ao Utilizador)
        public string? ClienteId { get; set; }
        public ApplicationUser? Cliente { get; set; }

        // Lista de produtos desta encomenda
        public List<DetalheEncomenda> Itens { get; set; } = new();
    }
}