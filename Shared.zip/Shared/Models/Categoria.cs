﻿namespace Shared
{
    public class Categoria
    {
        public int Id { get; set; }
        public string Nome { get; set; } = string.Empty;


        [System.Text.Json.Serialization.JsonIgnore] // To prevent circular references during serialization
        public List<Artigo>? Artigos { get; set; }

        public string Descricao { get; set; } = string.Empty;
    }
}
