using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace Shared
{
    // Novo Enum para gerir os 3 estados
    public enum EstadoConta
    {
        Pendente, // Acabou de se registar
        Ativo,    // Aprovado / Pode entrar
        Inativo   // Bloqueado / Banido
    }

    public class ApplicationUser : IdentityUser
    {
        [PersonalData]
        public string? Nome { get; set; }

        [PersonalData]
        public string? Apelido { get; set; }

        [PersonalData]
        public int NIF { get; set; }

        // --- MUDAN�A: Usar Enum em vez de boolean ---
        public EstadoConta Estado { get; set; } = EstadoConta.Pendente;
    }
}
